// src/config.js
// Replace with your actual backend URL if deployed
// export const API_BASE_URL = "http://localhost:5000/api";
export const API_BASE_URL = "https://api.loksar.co.uk/api";
